export class Admin{
    username:string;
    password:string;
}