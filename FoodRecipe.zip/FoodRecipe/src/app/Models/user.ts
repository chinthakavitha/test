export class User {
    username: string;
    email: string;
    password: string;
    name: string;
    contact: string;
    address: string;
}